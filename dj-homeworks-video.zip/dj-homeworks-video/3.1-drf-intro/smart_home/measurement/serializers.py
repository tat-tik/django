from rest_framework import serializers

# TODO: опишите необходимые сериализаторы
