from django.urls import path

urlpatterns = [
    # TODO: зарегистрируйте необходимые маршруты
]
