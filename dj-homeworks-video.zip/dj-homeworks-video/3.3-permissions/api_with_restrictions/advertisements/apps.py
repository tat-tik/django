from django.apps import AppConfig


class AdvertisementsConfig(AppConfig):
    name = 'advertisements'
